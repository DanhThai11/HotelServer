create definer = springstudent@`%` event delete_expired_tokens on schedule
    every '12' HOUR
        starts '2025-05-03 01:15:37'
    enable
    do
    DELETE FROM invalidated_token WHERE expiry_time < NOW();

