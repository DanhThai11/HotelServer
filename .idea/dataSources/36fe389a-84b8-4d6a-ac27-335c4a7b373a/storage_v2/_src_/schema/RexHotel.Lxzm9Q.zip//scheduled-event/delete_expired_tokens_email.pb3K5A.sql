create definer = springstudent@`%` event delete_expired_tokens_email on schedule
    every '12' HOUR
        starts '2025-05-03 01:20:17'
    enable
    do
    DELETE FROM email_verification_token WHERE expiry_date < NOW();

